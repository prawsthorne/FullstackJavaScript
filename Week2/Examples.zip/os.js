var os = require('os');

console.log("Platform: " + os.platform());
console.log("Architecture: " + os.arch());

console.log("hostname: " + os.hostname());
console.log("freemem: " + os.freemem());
